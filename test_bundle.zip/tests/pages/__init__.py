from alerts_page import AlertsPage
from login_page import LoginPage
from navigation_page import NavigationPage
from nested_views_page import NestedViewsPage
from web_page import WebPage
from tests.pages.base_pages.tab_view_page import TabViewPage
from tests.pages.native.video_player_page import VideoPlayerPage
from tests.pages.native.image_gallery_page import ImageGalleryPage
